import React from 'react'
import { render } from 'react-dom'
import { HashRouter as Router} from 'react-router-dom'

/**
 * react router init
 */
const rootRoute = {
	component: 'div',
	childRoutes: [{
		path: '/',
		component: require('./components/App'),
		childRoutes: [
			require('./routes/Index/index'),
			require('./routes/My/index') // last
		]
	}]
}

console.log(Router)

render(
	<Router  routes={rootRoute} />,
	document.getElementById('app')
)
