import React, { Component } from 'react'

class App extends Component {
	constructor(props) {
		super(props)
	}
	render() {
		console.log("index")
		return <div>App</div>
	}
}

export { App }