import React, { Component } from 'react'

class Index extends Component {
	constructor(props) {
		super(props)
	}
	render() {
		console.log("/index")
		return <div>Index</div>
	}
}

export { Index }