import React, { Component } from 'react'

class Index extends Component {
	constructor(props) {
		super(props)
	}
	render() {
		console.log("My")
		return <div>My</div>
	}
}

export { Index }