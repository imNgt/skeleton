const path = require('path');
const webpack = require('webpack');
const ExtractTextPlugin = require('extract-text-webpack-plugin');
const CleanWebpackPlugin = require('clean-webpack-plugin');


const isDev = process.env.NODE_ENV === 'dev';

const config = {
	entry: {
		app: path.resolve(__dirname, 'app/app.js')
	},
	output: {
		publicPath: `./public/dist/`,
		path: path.resolve(__dirname, './public/dist'),
		chunkFilename: isDev ? 'js/[name].js' : 'js/[name]-[hash:6].js',
		filename: 'js/[name].js'
	},
	module: {
		rules: [
			{
				test: /\.css$/,
				use: ExtractTextPlugin.extract({
					fallback: 'style-loader',
					use: ['css-loader', 'postcss-loader']
				})
			},
			{
				test: /\.scss$/,
				use: ExtractTextPlugin.extract({
					fallback: 'style-loader',
					use: ['css-loader', 'sass-loader']
				})
			},
			{
				test: /\.js$/,
				exclude: /(node_modules|bower_components)/,
				use: {
					loader: 'babel-loader',
					options: {
						presets: ['es2015', 'react', 'stage-0'],
						plugins: []
					}
				}
			}
		]
	},
	plugins: [
		// new webpack.optimize.CommonsChunkPlugin({
		// 	name: "vendors",
		// 	filename: "js/commons.js"
		// }),
		new ExtractTextPlugin('css/[name].css'),
		new CleanWebpackPlugin('public/dist')
	],
	devtool: isDev ? 'eval-source-map' : 'cheap-source-map',
	resolve: {
		alias: {},
		extensions: ['*', '.js', '.json', '.scss']
	}
};

module.exports = config;
